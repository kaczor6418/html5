export default [
    {
        photoUrl: 'https://upload.wikimedia.org/wikipedia/en/thumb/5/58/Instagram_egg.jpg/220px-Instagram_egg.jpg',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://cdn.galleries.smcloud.net/t/galleries/gf-puXc-6XNh-VWHh_marchew-664x442-nocrop.jpg',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://api.time.com/wp-content/uploads/2020/04/Boss-Turns-Into-Potato.jpg',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://leclercdrive.lublin.pl/122355-large_default/brokul-1-szt_.jpg',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://www.rijkzwaan.pl/sites/default/files/styles/image_450x450/public/varieties/17020_RZNL101004_001_Akela%20RZ_demonl1_%20.jpg?itok=4IVsVxl8',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://www.sklepdemo.pl/dane/full/e/e4e0b7c95aff4905a4d4a4b7ef011c39.jpg',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://a.allegroimg.com/s1024/0cdf5f/361e4e234583b247cf17960e9d0e',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://wyposazamysklepy.pl/environment/cache/images/500_500_productGfx_6d2edc11215c3251385bd9b6fa551920.jpg',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://dodomku.pl/images/products/full/00055610.jpg?id=1466078275',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
    {
        photoUrl: 'https://sklep.stokrotka.pl/files/fotob/product-9974.jpg',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eleifend lacus viverra, tincidunt purus vestibulum, semper ante. Mauris mollis lacus.'
    },
];